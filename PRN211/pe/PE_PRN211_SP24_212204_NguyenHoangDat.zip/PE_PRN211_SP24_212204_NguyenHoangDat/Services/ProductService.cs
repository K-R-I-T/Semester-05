﻿using Repositories;
using Repositories.Models;

namespace Services
{
    public class ProductService
    {
        private ProductRepository _repo = new();

        public List<Product> GetProducts()
        {
            return _repo.GetProducts();
        }

        public void Add(Product p)
        {
            _repo.AddProduct(p);
        }

        public void Update(Product p)
        {
            _repo.UpdateProduct(p);
        }

        public void Remove(Product p)
        {
            _repo.RemoveProduct(p);
        }
    }
}
