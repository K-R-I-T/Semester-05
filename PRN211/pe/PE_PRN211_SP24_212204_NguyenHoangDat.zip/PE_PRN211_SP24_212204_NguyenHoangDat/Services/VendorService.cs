﻿using Repositories;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class VendorService
    {
        private VendorRepository _repo = new();

        public List<Vendor> GetVendors()
        {
            return _repo.GetVendors();
        }
    }
}
