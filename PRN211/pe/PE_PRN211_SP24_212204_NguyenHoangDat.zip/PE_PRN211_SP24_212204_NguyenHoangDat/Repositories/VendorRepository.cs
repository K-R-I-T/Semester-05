﻿using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class VendorRepository
    {
        private ConvenienceStoreDbContext _context;

        public List<Vendor> GetVendors()
        {
            _context = new();
            return _context.Vendors.ToList();
        }
    }
}
