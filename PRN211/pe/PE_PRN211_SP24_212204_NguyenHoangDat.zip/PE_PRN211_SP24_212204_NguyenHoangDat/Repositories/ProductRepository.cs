﻿using Repositories.Models;

namespace Repositories
{
    public class ProductRepository
    {
        private ConvenienceStoreDbContext _context;

        public List<Product> GetProducts()
        {
            _context = new();
            return _context.Products.ToList();
        }

        public void AddProduct(Product p)
        {
            _context = new();
            _context.Add(p);
            _context.SaveChanges();
        }

        public void UpdateProduct(Product p)
        {
            _context = new();
            _context.Update(p);
            _context.SaveChanges();
        }

        public void RemoveProduct(Product p)
        {
            _context = new();
            _context.Remove(p);
            _context.SaveChanges();
        }
    }
}
