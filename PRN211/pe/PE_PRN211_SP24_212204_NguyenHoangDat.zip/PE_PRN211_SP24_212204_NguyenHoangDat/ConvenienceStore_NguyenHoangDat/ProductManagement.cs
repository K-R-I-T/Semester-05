﻿using Microsoft.IdentityModel.Tokens;
using Repositories.Models;
using Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvenienceStore_NguyenHoangDat
{
    public partial class ProductManagement : Form
    {
        private ProductService _productService = new();
        private Product _selected = null;
        public ProductManagement()
        {
            InitializeComponent();
        }

        private void FillDataGridView()
        {
            dgvProductList.DataSource = null;
            foreach (Product p in _productService.GetProducts())
            {
            }
            dgvProductList.DataSource = _productService.GetProducts();
        }

        private void ProductManagement_Load(object sender, EventArgs e)
        {
            FillDataGridView();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtProductName.Text.IsNullOrEmpty() || txtDescription.Text.IsNullOrEmpty())
            {
                dgvProductList.DataSource = null;
                dgvProductList.DataSource = _productService.GetProducts().Where(x => x.ProductName.ToLower().Contains(txtProductName.Text.ToLower()) || x.Description.ToLower().Contains(txtDescription.Text.ToLower())).ToList();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (_selected == null)
            {
                MessageBox.Show("Select a product!!");
                return;
            }
            DialogResult answer = MessageBox.Show("Are you sure you want to delete this product!", "Are you sure?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                _productService.Remove(_selected);
                _selected = null;
                FillDataGridView();
            }
        }

        private void dgvProductList_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvProductList.SelectedRows.Count > 0)
                _selected = (Product)dgvProductList.SelectedRows[0].DataBoundItem;
            else
                _selected = null;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ProductDetailForm f = new();
            f.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            ProductDetailForm f = new();
            f.Selected = _selected;
            f.ShowDialog();
        }
    }
}
