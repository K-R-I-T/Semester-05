﻿using Repositories.Models;
using Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvenienceStore_NguyenHoangDat
{
    public partial class ProductDetailForm : Form
    {
        public Product Selected { get; set; } = null;
        private VendorService _vendorService = new();
        private ProductService _productService = new();
        public ProductDetailForm()
        {
            InitializeComponent();
        }

        private void ProductDetailForm_Load(object sender, EventArgs e)
        {
            cboVendor.DataSource = _vendorService.GetVendors();
            cboVendor.DisplayMember = "VendorName";
            cboVendor.ValueMember = "VendorId";
            cboVendor.SelectedValue = 1;

            if (Selected != null)
            {
                txtProductId.Enabled = false;
                txtProductId.Text = Selected.ProductId.ToString();
                txtProductName.Text = Selected.ProductName;
                txtPrice.Text = Selected.Price.ToString();
                dtpExpiredDate.Value = DateTime.Parse(Selected.ExpiredDate.ToString());
                dtpManufactureDate.Value = DateTime.Parse(Selected.ManufactureDate.ToString());
                txtQuantity.Text = Selected.Quantity.ToString();
                txtDescription.Text = Selected.Description;
                cboVendor.SelectedValue = Selected.Vendor;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Product p = new Product() { 
                ProductId = int.Parse(txtProductId.Text),
                ProductName = txtProductName.Text,
                Price = int.Parse(txtPrice.Text),
                ExpiredDate = DateOnly.Parse(dtpExpiredDate.ToString()),
                ManufactureDate = DateOnly.Parse(dtpManufactureDate.ToString()),
                Quantity = int.Parse(txtQuantity.Text),
                Description = txtDescription.Text,
                VendorId = int.Parse(cboVendor.Text)
            };
            if (Selected != null)
            {
                _productService.Update(p);
            } else
            {
                _productService.Add(p);
            }
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
