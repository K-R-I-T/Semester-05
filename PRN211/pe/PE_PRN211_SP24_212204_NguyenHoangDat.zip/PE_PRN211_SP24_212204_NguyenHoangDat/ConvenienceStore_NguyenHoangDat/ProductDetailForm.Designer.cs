﻿namespace ConvenienceStore_NguyenHoangDat
{
    partial class ProductDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grbSearch = new GroupBox();
            txtPrice = new TextBox();
            dtpManufactureDate = new DateTimePicker();
            dtpExpiredDate = new DateTimePicker();
            txtQuantity = new TextBox();
            cboVendor = new ComboBox();
            lblVendorName = new Label();
            lblQuantity = new Label();
            lblManufactureDate = new Label();
            lblExpiredDate = new Label();
            lblPrice = new Label();
            txtProductId = new TextBox();
            lblProductId = new Label();
            txtDescription = new TextBox();
            lblDescription = new Label();
            txtProductName = new TextBox();
            lblProductName = new Label();
            btnSave = new Button();
            btnCancel = new Button();
            grbSearch.SuspendLayout();
            SuspendLayout();
            // 
            // grbSearch
            // 
            grbSearch.Controls.Add(txtPrice);
            grbSearch.Controls.Add(dtpManufactureDate);
            grbSearch.Controls.Add(dtpExpiredDate);
            grbSearch.Controls.Add(txtQuantity);
            grbSearch.Controls.Add(cboVendor);
            grbSearch.Controls.Add(lblVendorName);
            grbSearch.Controls.Add(lblQuantity);
            grbSearch.Controls.Add(lblManufactureDate);
            grbSearch.Controls.Add(lblExpiredDate);
            grbSearch.Controls.Add(lblPrice);
            grbSearch.Controls.Add(txtProductId);
            grbSearch.Controls.Add(lblProductId);
            grbSearch.Controls.Add(txtDescription);
            grbSearch.Controls.Add(lblDescription);
            grbSearch.Controls.Add(txtProductName);
            grbSearch.Controls.Add(lblProductName);
            grbSearch.Location = new Point(12, 61);
            grbSearch.Name = "grbSearch";
            grbSearch.Size = new Size(555, 377);
            grbSearch.TabIndex = 1;
            grbSearch.TabStop = false;
            grbSearch.Text = "Search Info";
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(138, 165);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(125, 27);
            txtPrice.TabIndex = 16;
            // 
            // dtpManufactureDate
            // 
            dtpManufactureDate.Format = DateTimePickerFormat.Short;
            dtpManufactureDate.Location = new Point(138, 230);
            dtpManufactureDate.Name = "dtpManufactureDate";
            dtpManufactureDate.Size = new Size(125, 27);
            dtpManufactureDate.TabIndex = 15;
            // 
            // dtpExpiredDate
            // 
            dtpExpiredDate.Format = DateTimePickerFormat.Short;
            dtpExpiredDate.Location = new Point(138, 201);
            dtpExpiredDate.Name = "dtpExpiredDate";
            dtpExpiredDate.Size = new Size(125, 27);
            dtpExpiredDate.TabIndex = 14;
            // 
            // txtQuantity
            // 
            txtQuantity.Location = new Point(138, 263);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(125, 27);
            txtQuantity.TabIndex = 13;
            // 
            // cboVendor
            // 
            cboVendor.FormattingEnabled = true;
            cboVendor.Location = new Point(138, 330);
            cboVendor.Name = "cboVendor";
            cboVendor.Size = new Size(125, 28);
            cboVendor.TabIndex = 12;
            // 
            // lblVendorName
            // 
            lblVendorName.AutoSize = true;
            lblVendorName.Location = new Point(6, 333);
            lblVendorName.Name = "lblVendorName";
            lblVendorName.Size = new Size(100, 20);
            lblVendorName.TabIndex = 11;
            lblVendorName.Text = "Vendor Name";
            // 
            // lblQuantity
            // 
            lblQuantity.AutoSize = true;
            lblQuantity.Location = new Point(6, 270);
            lblQuantity.Name = "lblQuantity";
            lblQuantity.Size = new Size(65, 20);
            lblQuantity.TabIndex = 10;
            lblQuantity.Text = "Quantity";
            // 
            // lblManufactureDate
            // 
            lblManufactureDate.AutoSize = true;
            lblManufactureDate.Location = new Point(6, 240);
            lblManufactureDate.Name = "lblManufactureDate";
            lblManufactureDate.Size = new Size(128, 20);
            lblManufactureDate.TabIndex = 9;
            lblManufactureDate.Text = "Manufacture Date";
            // 
            // lblExpiredDate
            // 
            lblExpiredDate.AutoSize = true;
            lblExpiredDate.Location = new Point(6, 201);
            lblExpiredDate.Name = "lblExpiredDate";
            lblExpiredDate.Size = new Size(95, 20);
            lblExpiredDate.TabIndex = 8;
            lblExpiredDate.Text = "Expired Date";
            // 
            // lblPrice
            // 
            lblPrice.AutoSize = true;
            lblPrice.Location = new Point(6, 167);
            lblPrice.Name = "lblPrice";
            lblPrice.Size = new Size(41, 20);
            lblPrice.TabIndex = 7;
            lblPrice.Text = "Price";
            // 
            // txtProductId
            // 
            txtProductId.Location = new Point(138, 28);
            txtProductId.Name = "txtProductId";
            txtProductId.Size = new Size(125, 27);
            txtProductId.TabIndex = 6;
            // 
            // lblProductId
            // 
            lblProductId.AutoSize = true;
            lblProductId.Location = new Point(6, 35);
            lblProductId.Name = "lblProductId";
            lblProductId.Size = new Size(79, 20);
            lblProductId.TabIndex = 5;
            lblProductId.Text = "Product ID";
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(138, 296);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(125, 27);
            txtDescription.TabIndex = 4;
            // 
            // lblDescription
            // 
            lblDescription.AutoSize = true;
            lblDescription.Location = new Point(6, 303);
            lblDescription.Name = "lblDescription";
            lblDescription.Size = new Size(85, 20);
            lblDescription.TabIndex = 3;
            lblDescription.Text = "Description";
            // 
            // txtProductName
            // 
            txtProductName.Location = new Point(138, 78);
            txtProductName.Multiline = true;
            txtProductName.Name = "txtProductName";
            txtProductName.ScrollBars = ScrollBars.Vertical;
            txtProductName.Size = new Size(125, 81);
            txtProductName.TabIndex = 2;
            // 
            // lblProductName
            // 
            lblProductName.AutoSize = true;
            lblProductName.Location = new Point(6, 85);
            lblProductName.Name = "lblProductName";
            lblProductName.Size = new Size(104, 20);
            lblProductName.TabIndex = 1;
            lblProductName.Text = "Product Name";
            // 
            // btnSave
            // 
            btnSave.Location = new Point(670, 87);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(94, 29);
            btnSave.TabIndex = 0;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(670, 177);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(94, 29);
            btnCancel.TabIndex = 2;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // ProductDetailForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCancel);
            Controls.Add(grbSearch);
            Controls.Add(btnSave);
            Name = "ProductDetailForm";
            Text = "ProductDetailForm";
            Load += ProductDetailForm_Load;
            grbSearch.ResumeLayout(false);
            grbSearch.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox grbSearch;
        private TextBox txtProductId;
        private Label lblProductId;
        private TextBox txtDescription;
        private Label lblDescription;
        private TextBox txtProductName;
        private Label lblProductName;
        private Button btnSave;
        private Button btnCancel;
        private DateTimePicker dtpManufactureDate;
        private DateTimePicker dtpExpiredDate;
        private TextBox txtQuantity;
        private ComboBox cboVendor;
        private Label lblVendorName;
        private Label lblQuantity;
        private Label lblManufactureDate;
        private Label lblExpiredDate;
        private Label lblPrice;
        private TextBox txtPrice;
    }
}