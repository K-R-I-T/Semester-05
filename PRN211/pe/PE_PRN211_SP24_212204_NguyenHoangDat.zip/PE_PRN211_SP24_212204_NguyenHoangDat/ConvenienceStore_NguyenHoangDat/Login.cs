using Repositories.Models;
using Services;

namespace ConvenienceStore_NguyenHoangDat
{
    public partial class Login : Form
    {
        private StoreAccountService _service = new();
        public Login()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            StoreAccount? sa = _service.CheckLogin(txtEmail.Text, txtPassword.Text);
            if (sa == null || sa.Role != 1)
            {
                MessageBox.Show("You have no permission to access this function!");
                return;
            }
            Hide();
            ProductManagement f = new();
            f.ShowDialog();
        }
    }
}
