﻿namespace AirConditionerShop_NguyenHoangDat
{
    partial class AirConditionerDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblWarranty = new Label();
            grbAirConditioner = new GroupBox();
            btnCancel = new Button();
            btnSave = new Button();
            lblSupplierName = new Label();
            cboSupplierName = new ComboBox();
            txtDollarPrice = new TextBox();
            txtQuantity = new TextBox();
            label2 = new Label();
            label1 = new Label();
            txtFeatureFunction = new TextBox();
            txtSoundPressureLevel = new TextBox();
            lblFeatureFunction = new Label();
            lblSoundPressureLevel = new Label();
            txtWarranty = new TextBox();
            lblAirConditionerName = new Label();
            lblAirConditionerId = new Label();
            txtAirConditionerName = new TextBox();
            txtAirConditionerId = new TextBox();
            btnSearch = new Button();
            grbAirConditioner.SuspendLayout();
            SuspendLayout();
            // 
            // lblWarranty
            // 
            lblWarranty.AutoSize = true;
            lblWarranty.Location = new Point(26, 164);
            lblWarranty.Name = "lblWarranty";
            lblWarranty.Size = new Size(68, 20);
            lblWarranty.TabIndex = 9;
            lblWarranty.Text = "Warranty";
            // 
            // grbAirConditioner
            // 
            grbAirConditioner.Controls.Add(btnCancel);
            grbAirConditioner.Controls.Add(btnSave);
            grbAirConditioner.Controls.Add(lblSupplierName);
            grbAirConditioner.Controls.Add(cboSupplierName);
            grbAirConditioner.Controls.Add(txtDollarPrice);
            grbAirConditioner.Controls.Add(txtQuantity);
            grbAirConditioner.Controls.Add(label2);
            grbAirConditioner.Controls.Add(label1);
            grbAirConditioner.Controls.Add(txtFeatureFunction);
            grbAirConditioner.Controls.Add(txtSoundPressureLevel);
            grbAirConditioner.Controls.Add(lblFeatureFunction);
            grbAirConditioner.Controls.Add(lblSoundPressureLevel);
            grbAirConditioner.Controls.Add(txtWarranty);
            grbAirConditioner.Controls.Add(lblAirConditionerName);
            grbAirConditioner.Controls.Add(lblWarranty);
            grbAirConditioner.Controls.Add(lblAirConditionerId);
            grbAirConditioner.Controls.Add(txtAirConditionerName);
            grbAirConditioner.Controls.Add(txtAirConditionerId);
            grbAirConditioner.Controls.Add(btnSearch);
            grbAirConditioner.Location = new Point(12, 40);
            grbAirConditioner.Name = "grbAirConditioner";
            grbAirConditioner.Size = new Size(834, 497);
            grbAirConditioner.TabIndex = 10;
            grbAirConditioner.TabStop = false;
            grbAirConditioner.Text = "Air Conditioner Info";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(603, 86);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(94, 29);
            btnCancel.TabIndex = 22;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(603, 51);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(94, 29);
            btnSave.TabIndex = 21;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // lblSupplierName
            // 
            lblSupplierName.AutoSize = true;
            lblSupplierName.Location = new Point(26, 352);
            lblSupplierName.Name = "lblSupplierName";
            lblSupplierName.Size = new Size(108, 20);
            lblSupplierName.TabIndex = 20;
            lblSupplierName.Text = "Supplier Name";
            // 
            // cboSupplierName
            // 
            cboSupplierName.FormattingEnabled = true;
            cboSupplierName.Location = new Point(194, 344);
            cboSupplierName.Name = "cboSupplierName";
            cboSupplierName.Size = new Size(151, 28);
            cboSupplierName.TabIndex = 19;
            // 
            // txtDollarPrice
            // 
            txtDollarPrice.Location = new Point(220, 296);
            txtDollarPrice.Name = "txtDollarPrice";
            txtDollarPrice.Size = new Size(125, 27);
            txtDollarPrice.TabIndex = 18;
            txtDollarPrice.Validating += txtDollarPrice_Validating;
            // 
            // txtQuantity
            // 
            txtQuantity.Location = new Point(220, 258);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(125, 27);
            txtQuantity.TabIndex = 17;
            txtQuantity.Validating += txtQuantity_Validating;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(26, 296);
            label2.Name = "label2";
            label2.Size = new Size(82, 20);
            label2.TabIndex = 16;
            label2.Text = "DollarPrice";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(26, 261);
            label1.Name = "label1";
            label1.Size = new Size(65, 20);
            label1.TabIndex = 15;
            label1.Text = "Quantity";
            // 
            // txtFeatureFunction
            // 
            txtFeatureFunction.Location = new Point(220, 224);
            txtFeatureFunction.Name = "txtFeatureFunction";
            txtFeatureFunction.Size = new Size(125, 27);
            txtFeatureFunction.TabIndex = 14;
            txtFeatureFunction.Validating += txtFeatureFunction_Validating;
            // 
            // txtSoundPressureLevel
            // 
            txtSoundPressureLevel.Location = new Point(220, 191);
            txtSoundPressureLevel.Name = "txtSoundPressureLevel";
            txtSoundPressureLevel.Size = new Size(125, 27);
            txtSoundPressureLevel.TabIndex = 13;
            txtSoundPressureLevel.Validating += txtSoundPressureLevel_Validating;
            // 
            // lblFeatureFunction
            // 
            lblFeatureFunction.AutoSize = true;
            lblFeatureFunction.Location = new Point(26, 231);
            lblFeatureFunction.Name = "lblFeatureFunction";
            lblFeatureFunction.Size = new Size(118, 20);
            lblFeatureFunction.TabIndex = 12;
            lblFeatureFunction.Text = "Feature Function";
            // 
            // lblSoundPressureLevel
            // 
            lblSoundPressureLevel.AutoSize = true;
            lblSoundPressureLevel.Location = new Point(26, 194);
            lblSoundPressureLevel.Name = "lblSoundPressureLevel";
            lblSoundPressureLevel.Size = new Size(147, 20);
            lblSoundPressureLevel.TabIndex = 11;
            lblSoundPressureLevel.Text = "Sound Pressure Level";
            // 
            // txtWarranty
            // 
            txtWarranty.Location = new Point(220, 157);
            txtWarranty.Name = "txtWarranty";
            txtWarranty.Size = new Size(125, 27);
            txtWarranty.TabIndex = 10;
            txtWarranty.Validating += txtWarranty_Validating;
            // 
            // lblAirConditionerName
            // 
            lblAirConditionerName.AutoSize = true;
            lblAirConditionerName.Location = new Point(26, 83);
            lblAirConditionerName.Name = "lblAirConditionerName";
            lblAirConditionerName.Size = new Size(154, 20);
            lblAirConditionerName.TabIndex = 9;
            lblAirConditionerName.Text = "Air Conditioner Name";
            // 
            // lblAirConditionerId
            // 
            lblAirConditionerId.AutoSize = true;
            lblAirConditionerId.Location = new Point(26, 38);
            lblAirConditionerId.Name = "lblAirConditionerId";
            lblAirConditionerId.Size = new Size(127, 20);
            lblAirConditionerId.TabIndex = 8;
            lblAirConditionerId.Text = "Air Conditioner Id";
            // 
            // txtAirConditionerName
            // 
            txtAirConditionerName.Location = new Point(220, 80);
            txtAirConditionerName.Multiline = true;
            txtAirConditionerName.Name = "txtAirConditionerName";
            txtAirConditionerName.ScrollBars = ScrollBars.Vertical;
            txtAirConditionerName.Size = new Size(125, 71);
            txtAirConditionerName.TabIndex = 7;
            txtAirConditionerName.Validating += txtAirConditionerName_Validating;
            // 
            // txtAirConditionerId
            // 
            txtAirConditionerId.Location = new Point(220, 35);
            txtAirConditionerId.Name = "txtAirConditionerId";
            txtAirConditionerId.Size = new Size(125, 27);
            txtAirConditionerId.TabIndex = 6;
            txtAirConditionerId.Validating += txtAirConditionerId_Validating;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(995, 35);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(94, 29);
            btnSearch.TabIndex = 5;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            // 
            // AirConditionerDetailForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1253, 531);
            Controls.Add(grbAirConditioner);
            Name = "AirConditionerDetailForm";
            Text = "AirConditionerDetailForm";
            Load += AirConditionerDetailForm_Load;
            grbAirConditioner.ResumeLayout(false);
            grbAirConditioner.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label lblWarranty;
        private GroupBox grbAirConditioner;
        private Label lblAirConditionerName;
        private Label lblAirConditionerId;
        private TextBox txtAirConditionerName;
        private TextBox txtAirConditionerId;
        private Button btnSearch;
        private Label lblSoundPressureLevel;
        private TextBox txtWarranty;
        private Label lblSupplierName;
        private ComboBox cboSupplierName;
        private TextBox txtDollarPrice;
        private TextBox txtQuantity;
        private Label label2;
        private Label label1;
        private TextBox txtFeatureFunction;
        private TextBox txtSoundPressureLevel;
        private Label lblFeatureFunction;
        private Button btnSave;
        private Button btnCancel;
    }
}