using Repositories.Models;
using Services;

namespace AirConditionerShop_NguyenHoangDat
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            StaffMemberService service = new();
            StaffMember? sm = service.CheckLogin(txtEmail.Text, txtPassword.Text);

            if (sm == null)
            {
                MessageBox.Show("Wrong email or password!", "Please try again!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (sm.Role != 1)
            {
                MessageBox.Show("You have no permission to access this function!", "Please try again!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            AirConditionerManagement acm = new();
            this.Hide();
            acm.ShowDialog();
        }
    }
}
