﻿using Microsoft.IdentityModel.Tokens;
using Repositories.Models;
using Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AirConditionerShop_NguyenHoangDat
{
    public partial class AirConditionerDetailForm : Form
    {
        private SupplierCompanyService _supplierCompanyService = new();
        private AirConditionerService _airConditionerService = new();
        public AirConditioner Selected { get; set; } = null;
        public AirConditionerDetailForm()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            AirConditioner ac = new()
            {
                AirConditionerId = int.Parse(txtAirConditionerId.Text),
                AirConditionerName = txtAirConditionerName.Text,
                Warranty = txtWarranty.Text,
                SoundPressureLevel = txtSoundPressureLevel.Text,
                FeatureFunction = txtFeatureFunction.Text,
                Quantity = int.Parse(txtQuantity.Text),
                DollarPrice = double.Parse(txtDollarPrice.Text),
                SupplierId = cboSupplierName.SelectedValue.ToString()
            };
            if (Selected != null)
                _airConditionerService.UpdateAirConditioner(ac);
            else
                _airConditionerService.CreateAirConditioner(ac);
            Close();

        }

        private void AirConditionerDetailForm_Load(object sender, EventArgs e)
        {
            cboSupplierName.DataSource = _supplierCompanyService.GetSupplierCompanies();
            cboSupplierName.DisplayMember = "SupplierName";
            cboSupplierName.ValueMember = "SupplierId";
            cboSupplierName.SelectedValue = "SC0005";

            if (Selected != null)
            {
                txtAirConditionerId.Enabled = false;
                txtAirConditionerId.Text = Selected.AirConditionerId.ToString();
                txtAirConditionerName.Text = Selected.AirConditionerName;
                txtWarranty.Text = Selected.Warranty;
                txtSoundPressureLevel.Text = Selected.SoundPressureLevel;
                txtFeatureFunction.Text = Selected.FeatureFunction;
                txtQuantity.Text = Selected.Quantity.ToString();
                txtDollarPrice.Text = Selected.DollarPrice.ToString();
                cboSupplierName.SelectedValue = Selected.SupplierId;
            }
        }

        private void txtAirConditionerName_Validating(object sender, CancelEventArgs e)
        {
            if (txtAirConditionerName.Text.IsNullOrEmpty() || txtAirConditionerName.Text.Length < 5 || txtAirConditionerName.Text.Length > 90)
            {
                MessageBox.Show("Invalid name");
                return;
            }
        }

        private void txtQuantity_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtQuantity.Text))
            {
                MessageBox.Show("Error");
                return;
            }

            if (int.Parse(txtQuantity.Text) < 0 || int.Parse(txtQuantity.Text) > 4000000)
            {
                MessageBox.Show("Invalid quantity!");
                return;
            }
        }

        private void txtDollarPrice_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtDollarPrice.Text))
            {
                MessageBox.Show("Error");
                return;
            }

            if (double.Parse(txtDollarPrice.Text) < 0 || double.Parse(txtDollarPrice.Text) > 4000000)
            {
                MessageBox.Show("Invalid quantity!");
                return;
            }
        }

        private void txtAirConditionerId_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtAirConditionerId.Text))
            {
                MessageBox.Show("Error");
                return;
            }
        }

        private void txtWarranty_Validating(object sender, CancelEventArgs e)
        {
            if (txtWarranty.Text.IsNullOrEmpty())
            {
                MessageBox.Show("Error");
                return;
            }
        }

        private void txtSoundPressureLevel_Validating(object sender, CancelEventArgs e)
        {
            if (txtSoundPressureLevel.Text.IsNullOrEmpty())
            {
                MessageBox.Show("Error");
                return;
            }
        }

        private void txtFeatureFunction_Validating(object sender, CancelEventArgs e)
        {
            if (txtFeatureFunction.Text.IsNullOrEmpty())
            {
                MessageBox.Show("Error");
                return;
            }
        }
    }
}
