﻿namespace AirConditionerShop_NguyenHoangDat
{
    partial class AirConditionerManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCreate = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            btnQuit = new Button();
            dgvAirConditioner = new DataGridView();
            btnSearch = new Button();
            grbSearch = new GroupBox();
            lblQuantity = new Label();
            lblFeatureFunction = new Label();
            txtQuantity = new TextBox();
            txtFeatureFunction = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvAirConditioner).BeginInit();
            grbSearch.SuspendLayout();
            SuspendLayout();
            // 
            // btnCreate
            // 
            btnCreate.Location = new Point(954, 157);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(94, 29);
            btnCreate.TabIndex = 0;
            btnCreate.Text = "Create";
            btnCreate.UseVisualStyleBackColor = true;
            btnCreate.Click += btnCreate_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(954, 192);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 29);
            btnUpdate.TabIndex = 1;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(954, 227);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 29);
            btnDelete.TabIndex = 2;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnQuit
            // 
            btnQuit.Location = new Point(954, 262);
            btnQuit.Name = "btnQuit";
            btnQuit.Size = new Size(94, 29);
            btnQuit.TabIndex = 3;
            btnQuit.Text = "Quit";
            btnQuit.UseVisualStyleBackColor = true;
            btnQuit.Click += btnQuit_Click;
            // 
            // dgvAirConditioner
            // 
            dgvAirConditioner.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAirConditioner.Location = new Point(12, 106);
            dgvAirConditioner.Name = "dgvAirConditioner";
            dgvAirConditioner.RowHeadersWidth = 51;
            dgvAirConditioner.Size = new Size(762, 422);
            dgvAirConditioner.TabIndex = 4;
            dgvAirConditioner.SelectionChanged += dgvAirConditioner_SelectionChanged;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(995, 35);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(94, 29);
            btnSearch.TabIndex = 5;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // grbSearch
            // 
            grbSearch.Controls.Add(lblQuantity);
            grbSearch.Controls.Add(lblFeatureFunction);
            grbSearch.Controls.Add(txtQuantity);
            grbSearch.Controls.Add(txtFeatureFunction);
            grbSearch.Controls.Add(btnSearch);
            grbSearch.Location = new Point(12, 10);
            grbSearch.Name = "grbSearch";
            grbSearch.Size = new Size(1226, 90);
            grbSearch.TabIndex = 6;
            grbSearch.TabStop = false;
            grbSearch.Text = "Search info";
            // 
            // lblQuantity
            // 
            lblQuantity.AutoSize = true;
            lblQuantity.Location = new Point(363, 42);
            lblQuantity.Name = "lblQuantity";
            lblQuantity.Size = new Size(65, 20);
            lblQuantity.TabIndex = 9;
            lblQuantity.Text = "Quantity";
            // 
            // lblFeatureFunction
            // 
            lblFeatureFunction.AutoSize = true;
            lblFeatureFunction.Location = new Point(26, 38);
            lblFeatureFunction.Name = "lblFeatureFunction";
            lblFeatureFunction.Size = new Size(118, 20);
            lblFeatureFunction.TabIndex = 8;
            lblFeatureFunction.Text = "Feature Function";
            // 
            // txtQuantity
            // 
            txtQuantity.Location = new Point(434, 35);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(125, 27);
            txtQuantity.TabIndex = 7;
            // 
            // txtFeatureFunction
            // 
            txtFeatureFunction.Location = new Point(150, 31);
            txtFeatureFunction.Name = "txtFeatureFunction";
            txtFeatureFunction.Size = new Size(125, 27);
            txtFeatureFunction.TabIndex = 6;
            // 
            // AirConditionerManagement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1259, 540);
            Controls.Add(grbSearch);
            Controls.Add(dgvAirConditioner);
            Controls.Add(btnQuit);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnCreate);
            Name = "AirConditionerManagement";
            Text = "AirConditionerManagement";
            Load += AirConditionerManagement_Load;
            ((System.ComponentModel.ISupportInitialize)dgvAirConditioner).EndInit();
            grbSearch.ResumeLayout(false);
            grbSearch.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btnCreate;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnQuit;
        private DataGridView dgvAirConditioner;
        private Button btnSearch;
        private GroupBox grbSearch;
        private Label lblQuantity;
        private Label lblFeatureFunction;
        private TextBox txtQuantity;
        private TextBox txtFeatureFunction;
    }
}