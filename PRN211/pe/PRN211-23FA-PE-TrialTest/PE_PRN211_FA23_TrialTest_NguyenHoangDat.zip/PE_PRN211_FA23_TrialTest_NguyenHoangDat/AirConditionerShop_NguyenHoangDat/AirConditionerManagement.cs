﻿using Microsoft.IdentityModel.Tokens;
using Repositories.Models;
using Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AirConditionerShop_NguyenHoangDat
{
    public partial class AirConditionerManagement : Form
    {
        private AirConditioner _selected = null;
        private AirConditionerService _service = new();
        private SupplierCompanyService _supplierCompanyService = new();
        public AirConditionerManagement()
        {
            InitializeComponent();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FillDataGridView()
        {
            dgvAirConditioner.DataSource = null;
            dgvAirConditioner.DataSource = _service.GetAirConditioners();

        }

        private void AirConditionerManagement_Load(object sender, EventArgs e)
        {
            FillDataGridView();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            dgvAirConditioner.DataSource = null;
            List<AirConditioner> airConditions = _service.GetAirConditioners();
            if (!txtFeatureFunction.Text.IsNullOrEmpty())
                airConditions = airConditions.Where(x => x.FeatureFunction.ToLower().Contains(txtFeatureFunction.Text.ToLower())).ToList();
            if (!txtQuantity.Text.IsNullOrEmpty())
                airConditions = airConditions.Where(x => x.Quantity == int.Parse(txtQuantity.Text)).ToList();
            dgvAirConditioner.DataSource = airConditions;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (_selected == null)
            {
                MessageBox.Show("Please select a book to delete", "Select one book", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            DialogResult answer = MessageBox.Show("Are you sure to delete this book?", "Delete book", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                _service.DeleteAirConditioner(_selected);
                _selected = null;
                FillDataGridView();
            }
        }

        private void dgvAirConditioner_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvAirConditioner.SelectedRows.Count > 0)
            {
                _selected = (AirConditioner)dgvAirConditioner.SelectedRows[0].DataBoundItem;
            }
            else
                _selected = null;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (_selected == null)
            {
                MessageBox.Show("Please select a book to update", "Select one book", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            AirConditionerDetailForm form = new();
            form.Selected = _selected;
            form.ShowDialog();
            FillDataGridView();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            AirConditionerDetailForm form = new();
            form.ShowDialog();
            FillDataGridView();
        }
    }
}
