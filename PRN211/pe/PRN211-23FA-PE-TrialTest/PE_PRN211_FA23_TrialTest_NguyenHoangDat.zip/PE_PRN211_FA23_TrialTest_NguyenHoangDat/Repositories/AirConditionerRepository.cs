﻿using Microsoft.EntityFrameworkCore;
using Repositories.Models;

namespace Repositories
{
    public class AirConditionerRepository
    {
        private AirConditionerShop2023DbContext _context;

        public List<AirConditioner> GetAirConditioners()
        {
            _context = new();
            return _context.AirConditioners.ToList();
        }

        public void CreateAirConditioner(AirConditioner ac)
        {
            _context = new();
            _context.AirConditioners.Add(ac);
            _context.SaveChanges();
        }

        public void UpdateAirConditioner(AirConditioner ac)
        {
            _context = new();
            _context.AirConditioners.Update(ac);
            _context.SaveChanges();
        }

        public void RemoveAirConditioner(AirConditioner ac)
        {
            _context = new();
            _context.AirConditioners.Remove(ac);
            _context.SaveChanges();
        }
    }
}
