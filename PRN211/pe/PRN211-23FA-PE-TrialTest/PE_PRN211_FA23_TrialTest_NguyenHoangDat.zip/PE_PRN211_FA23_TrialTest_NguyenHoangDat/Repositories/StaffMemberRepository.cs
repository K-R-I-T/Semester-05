﻿using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class StaffMemberRepository
    {
        private AirConditionerShop2023DbContext _context;

        public StaffMember? GetStaffMember(string email, string password)
        {
            _context = new();
            return _context.StaffMembers.FirstOrDefault(sm => sm.EmailAddress == email && sm.Password == password);
        }
    }
}
