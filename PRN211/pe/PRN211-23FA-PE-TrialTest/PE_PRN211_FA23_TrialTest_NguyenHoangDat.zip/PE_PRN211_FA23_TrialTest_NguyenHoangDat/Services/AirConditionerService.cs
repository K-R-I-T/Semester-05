﻿using Repositories;
using Repositories.Models;

namespace Services
{
    public class AirConditionerService
    {
        private AirConditionerRepository _repo = new();

        public List<AirConditioner> GetAirConditioners()
        {
            return _repo.GetAirConditioners();
        }

        public void CreateAirConditioner(AirConditioner ac)
        {
            _repo.CreateAirConditioner(ac);
        }

        public void UpdateAirConditioner(AirConditioner ac)
        {
            _repo.UpdateAirConditioner(ac);
        }

        public void DeleteAirConditioner(AirConditioner ac)
        {
            _repo.RemoveAirConditioner(ac);
        }
    }
}
