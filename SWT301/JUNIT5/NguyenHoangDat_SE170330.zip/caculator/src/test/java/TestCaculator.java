import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

import com.junit5.Caculator;

class TestCaculator {
    @ParameterizedTest
    @CsvFileSource(resources = "/addition.csv", numLinesToSkip = 1)
    void testAddition(double a, double b, double result) {
        Caculator caculator = new Caculator();
        assertEquals(caculator.add(a, b), result);
    }

    @ParameterizedTest
    @CsvFileSource(resources = "/subtraction.csv", numLinesToSkip = 1)
    void testSubtraction(double a, double b, double result) {
        Caculator caculator = new Caculator();
        assertEquals(caculator.subtract(a, b), result);
    }

    @ParameterizedTest
    @CsvFileSource(resources = "/multiplication.csv", numLinesToSkip = 1)
    void testMultiplication(double a, double b, double result) {
        Caculator caculator = new Caculator();
        assertEquals(caculator.multiply(a, b), result);
    }

    @ParameterizedTest
    @CsvFileSource(resources = "/division.csv", numLinesToSkip = 1)
    void testDivision(double a, double b, double result) {
        Caculator caculator = new Caculator();
        assertEquals(caculator.divide(a, b), result);
    }
}
